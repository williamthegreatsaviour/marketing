import React from 'react';
import { Check } from 'lucide-react';
import { PricingTier } from '../types';

interface PricingCardProps {
  tier: PricingTier;
}

export function PricingCard({ tier }: PricingCardProps) {
  return (
    <div className={`rounded-2xl p-8 ${tier.popular ? 'bg-blue-50 border-2 border-blue-500' : 'bg-white'} shadow-xl`}>
      {tier.popular && (
        <span className="inline-block px-4 py-1 text-sm font-semibold text-blue-600 bg-blue-100 rounded-full mb-4">
          Most Popular
        </span>
      )}
      <h3 className="text-2xl font-bold text-gray-900">{tier.name}</h3>
      <p className="mt-4 text-gray-600">{tier.description}</p>
      <p className="mt-8">
        <span className="text-4xl font-bold text-gray-900">
          ${tier.price}
        </span>
        <span className="text-gray-600">/month</span>
      </p>
      <ul className="mt-8 space-y-4">
        {tier.features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <Check className="h-5 w-5 text-green-500 mr-2" />
            <span className="text-gray-600">{feature}</span>
          </li>
        ))}
      </ul>
      <button className={`mt-8 w-full py-3 px-6 rounded-lg font-semibold 
        ${tier.popular 
          ? 'bg-blue-600 text-white hover:bg-blue-700' 
          : 'bg-gray-900 text-white hover:bg-gray-800'}`}>
        {tier.buttonText}
      </button>
    </div>
  );
}