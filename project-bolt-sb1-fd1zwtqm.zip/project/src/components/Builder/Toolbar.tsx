import React, { useState } from 'react';
import { Plus, Type, Image, CreditCard, Share2, Bot, X } from 'lucide-react';
import type { WebsiteComponent } from '../../types';
import { PaymentSettings } from './PaymentSettings';
import { SocialMediaSettings } from './SocialMediaSettings';
import { ChatbotSettings } from './ChatbotSettings';
import { useAuthStore } from '../../store/authStore';

interface ToolbarProps {
  onAddComponent: (component: Partial<WebsiteComponent>) => void;
}

export function Toolbar({ onAddComponent }: ToolbarProps) {
  const [showPaymentSettings, setShowPaymentSettings] = useState(false);
  const [showSocialSettings, setShowSocialSettings] = useState(false);
  const [showChatbotSettings, setShowChatbotSettings] = useState(false);
  const user = useAuthStore(state => state.user);

  const tools = [
    {
      icon: <Type className="w-5 h-5" />,
      label: 'Add Text',
      onClick: () => onAddComponent({
        type: 'text',
        content: { text: 'New text block' },
        style: { fontSize: '16px', color: '#000000' }
      })
    },
    {
      icon: <Image className="w-5 h-5" />,
      label: 'Add Image',
      onClick: () => onAddComponent({
        type: 'image',
        content: { url: '', alt: '' },
        style: { width: '100%', maxWidth: '500px' }
      })
    },
    {
      icon: <CreditCard className="w-5 h-5" />,
      label: 'Add Payment',
      onClick: () => setShowPaymentSettings(true)
    },
    {
      icon: <Share2 className="w-5 h-5" />,
      label: 'Social Media',
      onClick: () => setShowSocialSettings(true),
      premium: true,
      requiredTier: 'plus'
    },
    {
      icon: <Bot className="w-5 h-5" />,
      label: 'Add Chatbot',
      onClick: () => setShowChatbotSettings(true),
      premium: true,
      requiredTier: 'premium'
    }
  ];

  const handlePaymentSettings = (settings: any) => {
    onAddComponent({
      type: 'payment',
      content: {
        provider: settings.provider,
        productName: settings.productName,
        price: settings.price,
        recurring: settings.recurring,
        interval: settings.interval
      },
      style: {}
    });
    setShowPaymentSettings(false);
  };

  const handleSocialSettings = (settings: any) => {
    console.log('Scheduling posts:', settings);
    setShowSocialSettings(false);
  };

  const handleChatbotSettings = (settings: any) => {
    onAddComponent({
      type: 'chatbot',
      content: {
        name: settings.name,
        welcomeMessage: settings.welcomeMessage,
        primaryColor: settings.primaryColor,
        position: settings.position
      },
      style: {}
    });
    setShowChatbotSettings(false);
  };

  const canAccessFeature = (requiredTier?: 'plus' | 'premium') => {
    if (!requiredTier) return true;
    if (!user) return false;
    if (requiredTier === 'plus') return ['plus', 'premium'].includes(user.subscription);
    if (requiredTier === 'premium') return user.subscription === 'premium';
    return false;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg">
      {showPaymentSettings ? (
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Payment Settings</h3>
            <button onClick={() => setShowPaymentSettings(false)} className="text-gray-500 hover:text-gray-700">
              <X className="w-5 h-5" />
            </button>
          </div>
          <PaymentSettings onSave={handlePaymentSettings} />
        </div>
      ) : showSocialSettings ? (
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Social Media Settings</h3>
            <button onClick={() => setShowSocialSettings(false)} className="text-gray-500 hover:text-gray-700">
              <X className="w-5 h-5" />
            </button>
          </div>
          <SocialMediaSettings onSave={handleSocialSettings} />
        </div>
      ) : showChatbotSettings ? (
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Chatbot Settings</h3>
            <button onClick={() => setShowChatbotSettings(false)} className="text-gray-500 hover:text-gray-700">
              <X className="w-5 h-5" />
            </button>
          </div>
          <ChatbotSettings onSave={handleChatbotSettings} />
        </div>
      ) : (
        <div className="p-4 space-y-2">
          {tools.map((tool, index) => {
            const isAccessible = canAccessFeature(tool.requiredTier);
            return (
              <button
                key={index}
                onClick={tool.onClick}
                disabled={!isAccessible}
                className={`w-full flex items-center justify-between p-2 rounded-lg transition-colors ${
                  isAccessible 
                    ? 'hover:bg-gray-100' 
                    : 'opacity-50 cursor-not-allowed bg-gray-50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  {tool.icon}
                  <span>{tool.label}</span>
                </div>
                {tool.premium && !isAccessible && (
                  <span className="text-xs text-blue-600 font-medium">
                    {tool.requiredTier === 'plus' ? 'Plus' : 'Premium'}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}