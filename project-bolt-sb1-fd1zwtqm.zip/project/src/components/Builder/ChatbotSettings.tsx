import React, { useState } from 'react';
import { Bot, MessageSquare } from 'lucide-react';

interface ChatbotSettingsProps {
  onSave: (settings: {
    name: string;
    welcomeMessage: string;
    primaryColor: string;
    position: 'left' | 'right';
  }) => void;
}

export function ChatbotSettings({ onSave }: ChatbotSettingsProps) {
  const [settings, setSettings] = useState({
    name: 'AI Assistant',
    welcomeMessage: 'Hello! How can I help you today?',
    primaryColor: '#2563eb',
    position: 'right' as const
  });

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700">Chatbot Name</label>
        <input
          type="text"
          value={settings.name}
          onChange={(e) => setSettings(s => ({ ...s, name: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="AI Assistant"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Welcome Message</label>
        <textarea
          value={settings.welcomeMessage}
          onChange={(e) => setSettings(s => ({ ...s, welcomeMessage: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={3}
          placeholder="Hello! How can I help you today?"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Primary Color</label>
        <input
          type="color"
          value={settings.primaryColor}
          onChange={(e) => setSettings(s => ({ ...s, primaryColor: e.target.value }))}
          className="mt-1 block w-full h-10 rounded-md border-gray-300"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Position</label>
        <div className="mt-1 flex space-x-4">
          <button
            onClick={() => setSettings(s => ({ ...s, position: 'left' }))}
            className={`flex-1 py-2 px-4 rounded-lg border ${
              settings.position === 'left' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
          >
            Left
          </button>
          <button
            onClick={() => setSettings(s => ({ ...s, position: 'right' }))}
            className={`flex-1 py-2 px-4 rounded-lg border ${
              settings.position === 'right' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
          >
            Right
          </button>
        </div>
      </div>

      <button
        onClick={() => onSave(settings)}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
      >
        Add Chatbot
      </button>
    </div>
  );
}