import React from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { CreditCard } from 'lucide-react';
import type { Website, WebsiteComponent } from '../../types';

interface CanvasProps {
  website: Website;
  onUpdate: (website: Website) => void;
}

export function Canvas({ website, onUpdate }: CanvasProps) {
  const onDragEnd = (result: any) => {
    if (!result.destination) return;

    const components = Array.from(website.components);
    const [reorderedItem] = components.splice(result.source.index, 1);
    components.splice(result.destination.index, 0, reorderedItem);

    onUpdate({
      ...website,
      components,
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-8 min-h-[600px]">
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="canvas">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="space-y-4"
            >
              {website.components.map((component, index) => (
                <Draggable
                  key={component.id}
                  draggableId={component.id}
                  index={index}
                >
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className="border-2 border-dashed border-gray-200 p-4 rounded-lg"
                    >
                      <ComponentRenderer component={component} />
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}

function ComponentRenderer({ component }: { component: WebsiteComponent }) {
  switch (component.type) {
    case 'header':
      return <h1 style={component.style}>{component.content.text}</h1>;
    case 'text':
      return <p style={component.style}>{component.content.text}</p>;
    case 'image':
      return <img src={component.content.url} alt={component.content.alt} style={component.style} />;
    case 'button':
      return <button style={component.style}>{component.content.text}</button>;
    case 'payment':
      return (
        <div className="p-6 border rounded-lg bg-white shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold">{component.content.productName}</h3>
            <CreditCard className="w-6 h-6 text-blue-600" />
          </div>
          <div className="mb-4">
            <p className="text-3xl font-bold">${component.content.price}</p>
            {component.content.recurring && (
              <p className="text-gray-600">per {component.content.interval}</p>
            )}
          </div>
          <button className={`w-full py-3 px-4 rounded-lg text-white font-medium ${
            component.content.provider === 'stripe' 
              ? 'bg-[#635BFF] hover:bg-[#4B45C6]' 
              : 'bg-[#0070BA] hover:bg-[#005EA6]'
          }`}>
            Pay with {component.content.provider === 'stripe' ? 'Stripe' : 'PayPal'}
          </button>
        </div>
      );
    default:
      return null;
  }
}