import React, { useState } from 'react';
import { CreditCard, PaypalIcon } from 'lucide-react';

interface PaymentSettingsProps {
  onSave: (settings: {
    provider: 'stripe' | 'paypal';
    productName: string;
    price: number;
    recurring: boolean;
    interval?: 'month' | 'year';
  }) => void;
}

export function PaymentSettings({ onSave }: PaymentSettingsProps) {
  const [settings, setSettings] = useState({
    provider: 'stripe' as const,
    productName: '',
    price: 0,
    recurring: false,
    interval: 'month' as const
  });

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Payment Provider</label>
        <div className="mt-1 flex space-x-4">
          <button
            onClick={() => setSettings(s => ({ ...s, provider: 'stripe' }))}
            className={`flex items-center px-4 py-2 rounded-lg border ${
              settings.provider === 'stripe' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-300'
            }`}
          >
            <CreditCard className="w-5 h-5 mr-2" />
            Stripe
          </button>
          <button
            onClick={() => setSettings(s => ({ ...s, provider: 'paypal' }))}
            className={`flex items-center px-4 py-2 rounded-lg border ${
              settings.provider === 'paypal' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-300'
            }`}
          >
            <PaypalIcon className="w-5 h-5 mr-2" />
            PayPal
          </button>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Product Name</label>
        <input
          type="text"
          value={settings.productName}
          onChange={e => setSettings(s => ({ ...s, productName: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Price</label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <span className="text-gray-500 sm:text-sm">$</span>
          </div>
          <input
            type="number"
            min="0"
            step="0.01"
            value={settings.price}
            onChange={e => setSettings(s => ({ ...s, price: parseFloat(e.target.value) }))}
            className="block w-full pl-7 pr-12 rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      </div>

      <div>
        <label className="flex items-center">
          <input
            type="checkbox"
            checked={settings.recurring}
            onChange={e => setSettings(s => ({ ...s, recurring: e.target.checked }))}
            className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          <span className="ml-2 text-sm text-gray-600">Recurring Payment</span>
        </label>
      </div>

      {settings.recurring && (
        <div>
          <label className="block text-sm font-medium text-gray-700">Billing Interval</label>
          <select
            value={settings.interval}
            onChange={e => setSettings(s => ({ ...s, interval: e.target.value as 'month' | 'year' }))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="month">Monthly</option>
            <option value="year">Yearly</option>
          </select>
        </div>
      )}

      <button
        onClick={() => onSave(settings)}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
      >
        Save Payment Settings
      </button>
    </div>
  );
}