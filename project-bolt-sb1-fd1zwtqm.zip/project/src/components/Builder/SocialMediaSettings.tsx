import React, { useState } from 'react';
import { Facebook, Instagram, Twitter } from 'lucide-react';

interface SocialMediaSettingsProps {
  onSave: (settings: {
    platforms: {
      facebook?: { enabled: boolean; message: string };
      instagram?: { enabled: boolean; message: string };
      twitter?: { enabled: boolean; message: string };
    };
    schedule: Date;
  }) => void;
}

export function SocialMediaSettings({ onSave }: SocialMediaSettingsProps) {
  const [settings, setSettings] = useState({
    platforms: {
      facebook: { enabled: false, message: '' },
      instagram: { enabled: false, message: '' },
      twitter: { enabled: false, message: '' }
    },
    schedule: new Date()
  });

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Social Media Platforms</h3>
        <div className="space-y-4">
          <div className="flex items-start space-x-4 p-4 border rounded-lg">
            <Facebook className="w-6 h-6 text-blue-600" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <label className="font-medium">Facebook</label>
                <input
                  type="checkbox"
                  checked={settings.platforms.facebook.enabled}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      facebook: { ...s.platforms.facebook, enabled: e.target.checked }
                    }
                  }))}
                  className="rounded border-gray-300 text-blue-600"
                />
              </div>
              {settings.platforms.facebook.enabled && (
                <textarea
                  value={settings.platforms.facebook.message}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      facebook: { ...s.platforms.facebook, message: e.target.value }
                    }
                  }))}
                  placeholder="Enter your Facebook post message..."
                  className="mt-2 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  rows={3}
                />
              )}
            </div>
          </div>

          <div className="flex items-start space-x-4 p-4 border rounded-lg">
            <Instagram className="w-6 h-6 text-pink-600" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <label className="font-medium">Instagram</label>
                <input
                  type="checkbox"
                  checked={settings.platforms.instagram.enabled}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      instagram: { ...s.platforms.instagram, enabled: e.target.checked }
                    }
                  }))}
                  className="rounded border-gray-300 text-pink-600"
                />
              </div>
              {settings.platforms.instagram.enabled && (
                <textarea
                  value={settings.platforms.instagram.message}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      instagram: { ...s.platforms.instagram, message: e.target.value }
                    }
                  }))}
                  placeholder="Enter your Instagram caption..."
                  className="mt-2 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  rows={3}
                />
              )}
            </div>
          </div>

          <div className="flex items-start space-x-4 p-4 border rounded-lg">
            <Twitter className="w-6 h-6 text-blue-400" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <label className="font-medium">X (Twitter)</label>
                <input
                  type="checkbox"
                  checked={settings.platforms.twitter.enabled}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      twitter: { ...s.platforms.twitter, enabled: e.target.checked }
                    }
                  }))}
                  className="rounded border-gray-300 text-blue-400"
                />
              </div>
              {settings.platforms.twitter.enabled && (
                <textarea
                  value={settings.platforms.twitter.message}
                  onChange={(e) => setSettings(s => ({
                    ...s,
                    platforms: {
                      ...s.platforms,
                      twitter: { ...s.platforms.twitter, message: e.target.value }
                    }
                  }))}
                  placeholder="Enter your tweet..."
                  className="mt-2 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  rows={3}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Schedule Post</label>
        <input
          type="datetime-local"
          value={settings.schedule.toISOString().slice(0, 16)}
          onChange={(e) => setSettings(s => ({
            ...s,
            schedule: new Date(e.target.value)
          }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <button
        onClick={() => onSave(settings)}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
      >
        Schedule Posts
      </button>
    </div>
  );
}