import React, { useState } from 'react';
import { Canvas } from '../components/Builder/Canvas';
import { Toolbar } from '../components/Builder/Toolbar';
import type { Website, WebsiteComponent } from '../types';
import { useAuthStore } from '../store/authStore';

export function Builder() {
  const user = useAuthStore(state => state.user);
  const [website, setWebsite] = useState<Website>({
    id: 'new',
    name: 'My Website',
    userId: user?.id || '',
    components: [],
    published: false
  });

  const handleAddComponent = (component: Partial<WebsiteComponent>) => {
    setWebsite(prev => ({
      ...prev,
      components: [...prev.components, {
        id: crypto.randomUUID(),
        ...component as WebsiteComponent
      }]
    }));
  };

  const handleUpdateWebsite = (updatedWebsite: Website) => {
    setWebsite(updatedWebsite);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex gap-8">
          <div className="w-64">
            <Toolbar onAddComponent={handleAddComponent} />
          </div>
          <div className="flex-1">
            <Canvas website={website} onUpdate={handleUpdateWebsite} />
          </div>
        </div>
      </div>
    </div>
  );
}