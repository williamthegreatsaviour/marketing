export interface PricingTier {
  name: string;
  price: number;
  description: string;
  features: string[];
  buttonText: string;
  popular?: boolean;
}

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

export interface User {
  id: string;
  email: string;
  subscription: 'free' | 'plus' | 'premium';
}

export interface Website {
  id: string;
  name: string;
  userId: string;
  components: WebsiteComponent[];
  published: boolean;
  publishedUrl?: string;
}

export interface WebsiteComponent {
  id: string;
  type: 'header' | 'text' | 'image' | 'button' | 'payment';
  content: Record<string, any>;
  style: Record<string, string>;
}