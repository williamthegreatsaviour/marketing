import React from 'react';
import { Layers, Share2, Bot } from 'lucide-react';
import { PricingCard } from './components/PricingCard';
import type { PricingTier, Feature } from './types';

function App() {
  const features: Feature[] = [
    {
      icon: 'Layers',
      title: 'Drag & Drop Website Builder',
      description: 'Create beautiful websites without any coding knowledge using our intuitive builder.'
    },
    {
      icon: 'Share2',
      title: 'Social Media Integration',
      description: 'Automate your social media posts across Facebook, Instagram, and X.'
    },
    {
      icon: 'Bot',
      title: 'AI Chatbot',
      description: 'Engage with your visitors 24/7 using our intelligent AI chatbot.'
    }
  ];

  const pricingTiers: PricingTier[] = [
    {
      name: 'Free',
      price: 0,
      description: 'Perfect for getting started with website building',
      features: [
        'Website builder',
        'PayPal integration',
        'Stripe integration',
        'Basic templates',
        'Mobile responsive designs'
      ],
      buttonText: 'Start Free'
    },
    {
      name: 'Plus',
      price: 33,
      description: 'Everything you need for growing businesses',
      features: [
        'All Free features',
        'Social media integration',
        'Facebook automation',
        'Instagram automation',
        'X automation',
        'Advanced analytics'
      ],
      buttonText: 'Start Plus',
      popular: true
    },
    {
      name: 'Premium',
      price: 97,
      description: 'Advanced features for professional creators',
      features: [
        'All Plus features',
        'AI chatbot',
        'Custom domain',
        'Priority support',
        'Advanced customization',
        'White-label option'
      ],
      buttonText: 'Start Premium'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Create Your Professional Website<br />Without Code
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Build stunning sales pages and payment systems with our drag & drop builder.
            No coding required.
          </p>
          <button className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors">
            Start Building Free
          </button>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Everything You Need to Succeed Online
          </h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-lg flex items-center justify-center">
                  {feature.icon === 'Layers' && <Layers className="w-6 h-6 text-blue-600" />}
                  {feature.icon === 'Share2' && <Share2 className="w-6 h-6 text-blue-600" />}
                  {feature.icon === 'Bot' && <Bot className="w-6 h-6 text-blue-600" />}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">
            Choose Your Plan
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Select the perfect plan for your needs. Upgrade or downgrade at any time.
          </p>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingTiers.map((tier, index) => (
              <PricingCard key={index} tier={tier} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;